import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { supabase } from '@/integrations/supabase';
import type { User as SupabaseUser, Session } from '@supabase/supabase-js';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  role: 'user' | 'admin';
}

interface RegisterData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  refreshUser: () => Promise<void>;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch user profile with memoization
  const fetchUserData = useCallback(async (supabaseUser: SupabaseUser): Promise<User | null> => {
    try {
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', supabaseUser.id)
        .single();

      if (profileError) {
        console.error('Profile fetch error:', profileError);
      }

      let isAdmin = profile?.role === 'admin';

      if (!isAdmin && !profile?.role) {
        try {
          const { data: userRole } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', supabaseUser.id)
            .eq('role', 'admin')
            .single();
          
          isAdmin = !!userRole;
        } catch (roleError) {
          // Role check failed, continue as non-admin
        }
      }

      if (!isAdmin) {
        try {
          const { data: roleData, error: roleError } = await supabase
            .rpc('check_user_role', { 
              check_user_id: supabaseUser.id, 
              check_role: 'admin' 
            });
          
          if (!roleError && roleData) {
            isAdmin = true;
          }
        } catch (roleError) {
          // RPC function doesn't exist, that's ok
        }
      }

      return {
        id: supabaseUser.id,
        email: supabaseUser.email!,
        firstName: profile?.first_name || '',
        lastName: profile?.last_name || '',
        phone: profile?.phone || '',
        role: isAdmin ? 'admin' : 'user',
      };
    } catch (error) {
      console.error('Error fetching user data:', error);
      return {
        id: supabaseUser.id,
        email: supabaseUser.email!,
        firstName: '',
        lastName: '',
        role: 'user',
      };
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    let authListener: { subscription: { unsubscribe: () => void } } | null = null;

    const init = async () => {
      try {
        // Check existing session on load
        const { data: { session: currentSession } } = await supabase.auth.getSession();
        
        if (!mounted) return;

        setSession(currentSession);
        if (currentSession?.user) {
          const userData = await fetchUserData(currentSession.user);
          if (mounted) {
            setUser(userData);
          }
        }
      } catch (error) {
        console.error('Error loading session:', error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }

      // Listen for auth state changes
      authListener = supabase.auth.onAuthStateChange(async (event, newSession) => {
        console.log('Auth state changed:', event);
        
        if (!mounted) return;

        setSession(newSession);
        
        if (newSession?.user) {
          const userData = await fetchUserData(newSession.user);
          if (mounted) {
            setUser(userData);
          }
        } else {
          if (mounted) {
            setUser(null);
          }
        }
      });
    };

    init();

    // Cleanup function
    return () => {
      mounted = false;
      if (authListener) {
        authListener.subscription.unsubscribe();
      }
    };
  }, [fetchUserData]);

  // Add session refresh on window focus
  useEffect(() => {
    const handleVisibilityChange = async () => {
      if (document.visibilityState === 'visible' && session) {
        try {
          // Refresh session when tab becomes visible again
          const { data: { session: refreshedSession } } = await supabase.auth.getSession();
          
          if (refreshedSession) {
            setSession(refreshedSession);
          } else {
            // Session expired, clear user
            setUser(null);
            setSession(null);
          }
        } catch (error) {
          console.error('Error refreshing session on visibility change:', error);
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [session]);

  const login = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      
      if (error) {
        console.error('Login error:', error);
        throw error;
      }
      
      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const register = async (data: RegisterData) => {
    try {
      const { error } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            first_name: data.firstName,
            last_name: data.lastName,
            phone: data.phone,
          },
        },
      });
      
      if (error) {
        console.error('Registration error:', error);
        throw error;
      }
      
      return true;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const logout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setSession(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const loginWithGoogle = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) throw error;
    } catch (error) {
      console.error('Google login error:', error);
    }
  };

  const refreshUser = async () => {
    try {
      const { data: { session: currentSession } } = await supabase.auth.getSession();
      if (currentSession?.user) {
        const userData = await fetchUserData(currentSession.user);
        setUser(userData);
      }
    } catch (error) {
      console.error('Error refreshing user:', error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        loginWithGoogle,
        refreshUser,
        isAuthenticated: !!user,
        isAdmin: user?.role === 'admin',
        loading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};