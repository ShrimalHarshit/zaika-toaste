// src/hooks/useSupabaseConnection.ts
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase';

export const useSupabaseConnection = () => {
  const [isConnected, setIsConnected] = useState(true);
  const [isChecking, setIsChecking] = useState(false);

  const checkConnection = useCallback(async () => {
    try {
      setIsChecking(true);
      // Simple health check query
      const { error } = await supabase
        .from('profiles')
        .select('id')
        .limit(1)
        .maybeSingle();
      
      setIsConnected(!error);
      return !error;
    } catch (error) {
      console.error('Connection check failed:', error);
      setIsConnected(false);
      return false;
    } finally {
      setIsChecking(false);
    }
  }, []);

  const reconnect = useCallback(async () => {
    console.log('Attempting to reconnect...');
    
    // Force refresh the auth session
    try {
      await supabase.auth.refreshSession();
    } catch (error) {
      console.error('Session refresh failed:', error);
    }

    // Check connection
    const connected = await checkConnection();
    
    if (connected) {
      console.log('Reconnection successful');
    } else {
      console.log('Reconnection failed');
    }
    
    return connected;
  }, [checkConnection]);

  // Check connection on mount and when tab becomes visible
  useEffect(() => {
    checkConnection();

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        console.log('Tab visible - checking connection...');
        reconnect();
      }
    };

    const handleOnline = () => {
      console.log('Network online - checking connection...');
      reconnect();
    };

    const handleOffline = () => {
      console.log('Network offline');
      setIsConnected(false);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Periodic connection check every 30 seconds
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') {
        checkConnection();
      }
    }, 30000);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [checkConnection, reconnect]);

  return { isConnected, isChecking, checkConnection, reconnect };
};